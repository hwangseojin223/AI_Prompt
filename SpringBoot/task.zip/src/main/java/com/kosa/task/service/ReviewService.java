package com.kosa.task.service;

import com.kosa.task.domain.Review;
import com.kosa.task.mapper.ReviewMapper;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReviewService {
    @Autowired
    private ReviewMapper reviewMapper;
//    @Autowired

    public void createReview(Review review) {
        reviewMapper.insertReview(review);
    }
    public boolean deleteReview(int reviewId) {
        int deletedCount = reviewMapper.deleteReview(reviewId);
        return deletedCount > 0;
    }

    public List<Review> getReviewsByRestaurantId(int restaurantId) {
        return reviewMapper.findReviewsByRestaurantId(restaurantId);
    }



}
