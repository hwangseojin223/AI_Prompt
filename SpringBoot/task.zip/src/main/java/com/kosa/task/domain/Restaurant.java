package com.kosa.task.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class Restaurant {
    private int id;
    private String name;
    private String address;
    private LocalDate created_at;
    private LocalDate updated_at;

//    @JsonIgnore
    private List<RestaurantMenu> menuList;
//    @JsonIgnore
    private List<Review> reviewList;
}
