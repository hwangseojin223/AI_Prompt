package com.kosa.task.domain;

import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;
@Data
public class RestaurantMenu {
    private int id;
    private int restaurant_id;
    private String name;
    private int price;
    private LocalDate created_at;
    private LocalDate updated_at;
}
