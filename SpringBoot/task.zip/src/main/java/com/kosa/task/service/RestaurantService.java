package com.kosa.task.service;

import com.kosa.task.domain.Restaurant;
import com.kosa.task.domain.RestaurantMenu;
import com.kosa.task.mapper.MenuMapper;
import com.kosa.task.mapper.RestaurantMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Service
public class RestaurantService {

    @Autowired
    private RestaurantMapper restaurantMapper;

    @Autowired
    private MenuMapper menuMapper;

    //레스토랑 정보 가져오기
    public List<Restaurant> getAllRestaurants() {
        return restaurantMapper.findAll();
    }
    //레스토랑 생성
    public Restaurant getRestaurantById(int id) {
        return restaurantMapper.findById(id);
    }

    // 레스토랑 생성(메뉴와 함께)
    @Transactional
    public void createRestaurant(Restaurant restaurant) {

        restaurantMapper.insertRestaurant(restaurant);

        int restaurantId = restaurant.getId();

        System.out.println("생성된 restaurantId: " + restaurantId);
        restaurantId ++;
        System.out.println("생성된 restaurantId: " + restaurantId);
        if(restaurant.getMenuList() != null) {
            for(RestaurantMenu menu : restaurant.getMenuList()) {
                menu.setRestaurant_id(restaurantId);
                menuMapper.insertMenu(menu);
            }
        }
    }

    public boolean deleteRestaurant(int restaurantId) {
        int deletedCount = restaurantMapper.deleteRestaurant(restaurantId);
        return deletedCount > 0;
    }

    //업데이트
    public void updateRestaurant(Restaurant restaurant) {
        restaurantMapper.updateRestaurant(restaurant);
    }

}
