package com.kosa.task.mapper;

import com.kosa.task.domain.Restaurant;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface RestaurantMapper {
    List<Restaurant> findAll();

    Restaurant findById(int id);

    // 레스토랑과 메뉴 삽입
    void insertRestaurant(Restaurant restaurant);
    int deleteRestaurant(int id);
    void updateRestaurant(Restaurant restaurant);
}