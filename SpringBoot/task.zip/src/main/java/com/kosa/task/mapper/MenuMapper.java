package com.kosa.task.mapper;

import com.kosa.task.domain.RestaurantMenu;
import org.apache.ibatis.annotations.Mapper;

import java.awt.*;
import java.util.List;

@Mapper
public interface MenuMapper {
    List<RestaurantMenu> findMenusByRestaurantId(int restaurantId);
    void insertMenu(RestaurantMenu menu);
}
