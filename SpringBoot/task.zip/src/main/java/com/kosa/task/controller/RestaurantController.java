package com.kosa.task.controller;

import com.kosa.task.domain.Restaurant;
import com.kosa.task.domain.Review;
import com.kosa.task.service.RestaurantService;
import com.kosa.task.service.ReviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class RestaurantController {

    @Autowired
    private RestaurantService restaurantService;
    @Autowired
    private ReviewService reviewService;

    // 맛집 리스트
    @GetMapping("/restaurants")
    public List<Restaurant> getAll() {
        return restaurantService.getAllRestaurants();
    }

    // 맛집 정보
    @GetMapping("/restaurant/{restaurantId}")
    public Restaurant getRestaurant(@PathVariable int restaurantId) {
        return restaurantService.getRestaurantById(restaurantId);
    }

    // 맛집 생성
    @PostMapping("/restaurant")
    public void createRestaurant(@RequestBody Restaurant restaurant) {
        restaurantService.createRestaurant(restaurant);
    }

    @DeleteMapping("/restaurant/{restaurantId}")
    public ResponseEntity<String> deleteRestaurant(@PathVariable int restaurantId) {
        boolean isDeleted = restaurantService.deleteRestaurant(restaurantId);

        if (isDeleted) {
            return ResponseEntity.ok("Deleted restaurant");
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PutMapping("restaurant/{restaurantId}")
    public ResponseEntity<String> updateRestaurant(@PathVariable int restaurantId, @RequestBody Restaurant restaurant) {
        restaurant.setId(restaurantId);
        restaurantService.updateRestaurant(restaurant);
        return ResponseEntity.ok("Restaurant updated");
    }

    @GetMapping("/restaurant/{restaurantId}/reviews")
    public List<Review> getReviews(@PathVariable int restaurantId) {
        return reviewService.getReviewsByRestaurantId(restaurantId);
    }

}


