package com.kosa.task.controller;

import com.kosa.task.domain.RestaurantMenu;
import com.kosa.task.service.MenuService;
import org.springframework.web.bind.annotation.*;

@RestController
public class MenuController {
    private MenuService menuService;

//    @GetMapping("/menus/restaurant/{restaurantId}")
//    public List<RestaurantMenu> getMenusByRestaurantId(@PathVariable int restaurantId) {
//        return menuService.getMenusByRestaurantId(restaurantId);
//    }
//
//    @PostMapping("/menus")
//    public void createMenu(@RequestBody RestaurantMenu restaurantMenu) {
//        menuService.createMenu(restaurantMenu);
//    }
}
