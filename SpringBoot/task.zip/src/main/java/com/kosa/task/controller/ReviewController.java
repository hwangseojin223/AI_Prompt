package com.kosa.task.controller;

import com.kosa.task.domain.Review;
import com.kosa.task.service.ReviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ReviewController {

    @Autowired
    private ReviewService reviewService;

    @PostMapping("/review")
    public void createReview(@RequestBody Review review) {
        reviewService.createReview(review);
    }

    @DeleteMapping("/review/{reviewId}")
    public ResponseEntity<String> deleteReview(@PathVariable int reviewId) {
       boolean isDeleted = reviewService.deleteReview(reviewId);

       if (isDeleted) {
           return ResponseEntity.ok("Deleted review");
       }
       else {
           return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
       }
    }

    @GetMapping("/reviews/restaurant/{restaurantId}")
    public List<Review> getReviewsByRestaurantId(@PathVariable int restaurantId) {
        return reviewService.getReviewsByRestaurantId(restaurantId);
    }
}
