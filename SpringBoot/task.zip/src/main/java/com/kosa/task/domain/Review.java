package com.kosa.task.domain;

import lombok.Data;

import java.time.LocalDate;
@Data
public class Review {
    private int id;
    private int restaurant_id;
    private String content;
    private double score;
    private LocalDate created_at;
}
