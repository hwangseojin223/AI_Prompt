package com.kosa.task.mapper;

import com.kosa.task.domain.Review;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface ReviewMapper {
    void insertReview(Review review);
    int deleteReview(int id);
    List<Review> findReviewsByRestaurantId(int restaurantId);

}
