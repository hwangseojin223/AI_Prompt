package com.kosa.task.service;

import com.kosa.task.domain.RestaurantMenu;
import com.kosa.task.mapper.MenuMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MenuService {
    private MenuMapper menuMapper;

    public MenuService(MenuMapper menuMapper) {
        this.menuMapper = menuMapper;
    }

    public List<RestaurantMenu> getMenusByRestaurantId(int restaurantId) {
        return menuMapper.findMenusByRestaurantId(restaurantId);
    }

    public void createMenu(RestaurantMenu restaurantMenu) {
        menuMapper.insertMenu(restaurantMenu);
    }
}
